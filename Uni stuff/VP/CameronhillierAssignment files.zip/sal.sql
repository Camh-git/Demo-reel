CREATE TABLE `data`.`employees` (
  `Employee id` INT NOT NULL,
  `Employee name` INT,
  `Employee age` INT NULL,
  `Employee department` VARCHAR(45) NULL,
  `employee salary (£)` VARCHAR(45) NULL,
  PRIMARY KEY (`Employee name`));