package crud;
import java.sql.*;
import java.util.Scanner;
import java.io.*;;

public class java_crud {

	public static void main(String[] args) {	
		try {
			//Create connection string
			getConnection();
			}
		catch(Exception e) {
			e.printStackTrace();
			System.out.println("");
			System.out.println("Failed to establish connection");
		}
		//Show the db on startup,setup the scanner, then run menu
		Read();		
		scan.useDelimiter(System.lineSeparator());
		ctrlAsk = true;
		control();		
		
		//transactions: jdbc autocommits by default, to change: conName.setAutoCommit(false);
		//to commit: conName.comit();, to rolback conName.rollback(); 
	}	
	
	static Connection con = null; 
	
	private static Connection getConnection(){
		try {
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/website_users", "root", "");
			con.setAutoCommit(false); //yes, I know there are no batch processes, it's here for demo purposes
		} 
		catch (SQLException e) {			
			e.printStackTrace();
		}
		return con;
	}		
	
	private static final Scanner scan = new Scanner(System.in);
	private static boolean ctrlAsk = false;

	public static void control ()
	{	
		/* while the system will complain about memory NEVER close a scanner that uses system.in*/
		System.gc();//tidying since this may not be our first time here
		String Choice = "a";
		while (Choice == "a") {	
			//getting the input
			if(ctrlAsk == false) {System.out.println("Please select action, availble actions: Create, Read, Update, Delete or Exit");}
			Choice = scan.nextLine();	
			switch (Choice.toUpperCase()) {
			case "CREATE": Create(); break;
			case "READ": Read(); break;
			case "UPDATE": Update(); break;
			case "DELETE": Delete(); break;
			case "EXIT": System.out.println("Shutting down"); scan.close(); System.exit(0); break;
			
			//on default: if the input was bad because the control was called by a method delete the previous line and go through again to
			//get input, else display the normal error message and go again
			default: if (ctrlAsk == true) {
				System.out.println("Invalid input, please try again"); Choice = "a";
				} else {
					//for (int i =0; i<76; i++) {System.out.print("\b");}	//eclipse doesn't like this				
					ctrlAsk = true;
					}
				}
				
			
		}
	}
	public static void Read() {
		//This method prints the contents of the table for the user
		try {
			PreparedStatement counter = con.prepareStatement("Select * From user_table");
			ResultSet res = counter.executeQuery();
			while (res.next()) {
				System.out.println(res.getInt("User_ID") + ", " +  res.getString("Username"));
			}	
		}
		catch (Exception e) {			
			System.out.println("Download failed");
			e.printStackTrace();
		}
		control();
	}
	
	public static void Create() {
		try {
			int acc_num = 1;
			String Username = "";
			String Password = "";
			int Status = 0;
			
			//getting new account num by finding current count and adding 1
			PreparedStatement counter = con.prepareStatement("Select * From user_table");
			ResultSet res = counter.executeQuery();					
			while (res.next()) {
				acc_num ++;
			}			
			//getting inputs
			System.out.println("Please enter the new user's name");
			Username = scan.next();
			System.out.println("Please enter the new user's password");
			Password = scan.next();
			System.out.println("Enter user admin status(0-no, 1-yes)");
			Status = scan.nextInt();
			
			//inserting
			PreparedStatement stmt = con.prepareStatement("INSERT INTO user_table (User_ID,Username,Password,Admin_status)Values(?,?,?,?)");			
			stmt.setInt(1, acc_num);//give real vars for each
			stmt.setString(2,Username);
			stmt.setString(3, Password);
			stmt.setInt(4, Status);
			
			stmt.executeUpdate();		
			con.commit();
			System.out.println("Created user: " + Username + ",password: " + Password + ", status: " + Status);
		}
		catch (SQLException e) {			
			System.out.println("Error inserting value");
			try {con.rollback();} catch (SQLException e1) {System.out.println("rollback error"); e1.printStackTrace();}			
			e.printStackTrace();
		}
		ctrlAsk = false;
		control();
	}

	public static void Update () {	
		try {
			int acc_num = 0;
			String Column = "";
			String Value = "";
			//getting inputs	
			try {		
				System.out.println("Please select the account you wish to edit(enter number)");
				acc_num = scan.nextInt();
				System.out.println("Please select the field you wish to edit(Username,Password)");
				Column = scan.next();
				System.out.println("Please write the new value");
				Value = scan.next();	
				}
			catch(Exception e){
				System.out.println("Invalid inputs detected, returning to function select");				
				}		
			//updating using prepared statements
			if(Column.toUpperCase().equals("USERNAME")) {
				PreparedStatement stmt = con.prepareStatement("UPDATE user_table SET Username = ? WHERE User_ID = ?");
				stmt.setString(1,Value);
				stmt.setInt(2,acc_num);	
				stmt.executeUpdate();
				con.commit();
				
			} else if (Column.toUpperCase().equals("PASSWORD")){
				PreparedStatement stmt = con.prepareStatement("UPDATE user_table SET Password = ? WHERE User_ID = ?");			
				stmt.setString(1,Value);
				stmt.setInt(2,acc_num);
			    stmt.executeUpdate();	
			    con.commit();
			    
			} else {
				System.out.println("Invalid Field detected");				
			}
			System.out.println("Updated user: " + acc_num);
		}
		catch(SQLException e){
			System.out.println("Error updating entry, returning to select");
			try {con.rollback();} catch (SQLException e1) {System.out.println("rollback error"); e1.printStackTrace();}	
			e.printStackTrace();
		}
		ctrlAsk = false;
		control();
	}
	public static void Delete() {
		try {
			System.out.println("Please select the account you wish to delete(enter number,0 to return)");
			int acc_num = scan.nextInt();			
			if (acc_num == 0) {
				control();
				return;
			}
			
			PreparedStatement stmt = con.prepareStatement("DELETE FROM `user_table` WHERE `user_table`.`User_ID` = ?");
			stmt.setInt(1, acc_num);
			int row_deleted = stmt.executeUpdate();
			con.commit();
			System.out.println("#Rows deleted: " + row_deleted + ", deleted account number: " + acc_num);			
			} 
		catch(SQLException e){
			System.out.println("Error deleting entry");
			try {con.rollback();} catch (SQLException e1) {System.out.println("rollback error"); e1.printStackTrace();}	
			e.printStackTrace();
			}	
		ctrlAsk = false;
		control();
	}
}
//mostly thanks to: https://www.youtube.com/watch?v=2i4t-SL1VsU (the whole early series is useful)
//needs jdbc




/* a more pro but not safe connection: https://stackoverflow.com/questions/20666658/how-can-i-use-one-database-connection-object-in-whole-application
 static Connection con=null;
    public static Connection getConnection()
    {
        if (con != null) return con;
        // get db, user, pass from settings file
        return getConnection(db, user, pass);
    }

    private static Connection getConnection(String db_name,String user_name,String password)
    {
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost/"+db_name+"?user="+user_name+"&password="+password);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        return con;        
    } 
 
 * */
