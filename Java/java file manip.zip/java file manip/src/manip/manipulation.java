package manip;
import java.util.*;
import java.lang.*;
import java.io.*;


public class manipulation {

	public static void main(String[] args) {
		//Read_file("apples");
		Write_to_file("apples");

	}
	public static void Create_file(String name) {
		try {
			File myFile = new File(name + ".txt");
			if (myFile.createNewFile()) {
				System.out.println("Created file called:" + myFile.getName() + ".");				
			} else {
				System.out.println("File with that name already exists.");
			}
		}
		catch(IOException e)
		{
			e.printStackTrace();
			System.out.println("An error occured when trying to create the file.");
		}
	}
	public static void Get_file_info(String FileName)
	{
		if (!FileName.contains(".txt"))	{
			FileName = FileName + ".txt";
		}
		File myFile = new File(FileName);
		if (myFile.exists()) {
			System.out.println("File name: " + myFile.getName());
		      System.out.println("Absolute path: " + myFile.getAbsolutePath());
		      System.out.println("Writeable: " + myFile.canWrite());
		      System.out.println("Readable " + myFile.canRead());
		      System.out.println("File size in bytes " + myFile.length());
		    } else {
		      System.out.println("The file does not exist.");
		}
	}
	public static void Read_file(String FileName)
	{
		if (!FileName.contains(".txt"))	{
			FileName = FileName + ".txt";
		}
		try {
		      File myFile= new File(FileName);
		      Scanner myReader = new Scanner(myFile);
		      while (myReader.hasNextLine()) {
		        String data = myReader.nextLine();
		        System.out.println(data);
		      }
		      myReader.close();
		    } catch (FileNotFoundException e) {
		      System.out.println("An error occurred.");
		      e.printStackTrace();
		    }
	}
	public static void Write_to_file(String FileName)
	{
		if (!FileName.contains(".txt"))	{
			FileName = FileName + ".txt";
		}
		try {
			FileWriter Writer = new FileWriter(FileName);
			Writer.write("This was written by java");
			BufferedWriter  output = new BufferedWriter(new FileWriter(FileName, true));
			
			Writer.close();
			System.out.println("Wrote to file");
		}
		catch(IOException e) {
			e.printStackTrace();
			System.out.println("An error occured when trying to write to the file.");
		}
	}
	public static void Delete_file(String FileName)
	{
		if (!FileName.contains(".txt"))	{
			FileName = FileName + ".txt";
		}
		File myFile = new File(FileName);  //this can also be done with folders, so long as they are empty
		if (myFile.delete()) { 
			System.out.println("Deleted the file: " + myFile.getName());
			} else {
				System.out.println("Failed to delete the file.");
		    }
	}

}
