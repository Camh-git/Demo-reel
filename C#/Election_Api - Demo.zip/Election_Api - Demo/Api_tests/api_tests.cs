using Microsoft.VisualStudio.TestTools.UnitTesting;

using Election_Api;
using Election_Api.Models;
using Election_Api.Controllers;

using Microsoft.Extensions.Logging;
using System.Data;
using MySql.Data.MySqlClient;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using System.Text.RegularExpressions;
using System.Diagnostics;
using System.IO;

namespace Api_tests
{    
    [TestClass]    
    public class api_tests
    {  


        
        /*TESTS AS FOLLOWS:*/
        /* 1: Good datasource
         * 2: Default code (letmein123) into Verify_code comes back true and with the correct con (1)
         * 3: Good normal code into Verify_code comes back true and with the correct con
         * 4: Bad code into Verify_code comes back false and with default con (0)
         * 5: Sending int 1 into GetCandidate_Items gets corrrect candidate info for con 1
         * 6: Sending int 47 into GetCandidate_Items gets correct candidate info for con 47
         * 7: Sending int 65 into GetCandidate_Items gets correct candidate info for con 65
         * 8: Sending int 999 into GetCandidate_Items gets no values without causing errors
         * 9: Sending int 0 into GetCandidate_Items gets it's values without causing errors(users with id 330 and 332)
         *10: Cast_vote returns code 0 (default) when provided with no info *
         *11: Cast_vote returns code 5 (bad connection) when trying to connect with db down *
         *12: Cast_vote returns code 3 (bad code) when given bad code   *
         *13: Cast_vote returns code 2 (bad choice) when given bad candidate id *
         *14: Cast_vote returns code 1 (good) when given valid candidate and code (1, letmein123) *
         */
        Election_controler Test_controller = new Election_controler(); //requires the contstructor in election_controler without logging to be uncommented
        private static MySqlConnection Test_con = new MySqlConnection("datasource = 192.168.0.15; port=3306; database=election_db; username=election_user; password=; allow user variables =True");


        [TestMethod]
        public void Good_datasource()
        {
            //Creates a connection using the test controler connection and tries to open it to ensure that it is good
            bool Success = false;
            using (MySqlConnection conn = new MySqlConnection(Test_con.ConnectionString))
            {
                try
                {
                    conn.Open();
                    Trace.WriteLine("opened");
                    Success = true;
                }
                catch { Success = false; /*just to be safe*/}

                try { conn.Close(); } catch { }
            }
            Assert.IsTrue(Success);

        }
        [TestMethod]
        public void Good_default_code()
        {
            string Code = "letmein123";

            Code_item Code_response = Test_controller.Verify_code(Code);

            Assert.IsTrue(Code_response.Valid = true);
            Assert.AreEqual(Code_response.Constituency, 1);
        }
        [TestMethod]
        public void Good_real_code()
        {
            //gets a real code from the db, checks if it's valid
            Random Rand = new Random();
            int Code_num = Rand.Next(0,1000);
            String Code = "";
            using (MySqlCommand Get_code = new MySqlCommand("SELECT Code FROM voter_codes WHERE Code_num = @Code_num",Test_con))
            {
                Get_code.Parameters.AddWithValue("Code_num",Code_num);
                try { Test_con.Open(); } catch { }
                using (MySqlDataReader Reader = Get_code.ExecuteReader() )
                {
                    while (Reader.Read())
                    {
                        Code = Reader.GetString(0);
                    }
                }
            }
            try { Test_con.Close(); } catch { }
            Code_item Code_response = Test_controller.Verify_code(Code);
            Assert.IsTrue(Code_response.Valid = true);
        }        
        [TestMethod]
        public void Bad_bad_code()
        {
            String Code = "aaaaaaaaaa";//This is a theoreticaly possible code that does not exist in the DB
            Code_item Code_response = Test_controller.Verify_code(Code);
            Assert.IsFalse(Code_response.Valid);
            Assert.AreEqual(Code_response.Constituency, 0);
        }

        //The constituencies used where chosen because the represent differnt numbers of candidates and therefore test how the system handles different response lengths
        //Only a selection of the expected details are tested to keep the code reasonably short, all test specifics (e.g con 65 not having as many candidates as con 1) are kept.
        [TestMethod]
        public void Good_info_con_1()
        {
            List<Candidate_item> Candidates = Test_controller.Candidate_list(1);
            Assert.AreNotEqual(Candidates[0].ID, 0);
            Assert.AreNotEqual(Candidates[5].ID, 0);

        }
        [TestMethod]
        public void Good_info_con_47()
        {
            List<Candidate_item> Candidates = Test_controller.Candidate_list(47);
            Assert.AreNotEqual(Candidates[0].ID, 0);
            Assert.IsTrue(Candidates.Count == 5);

        }
        [TestMethod]
        public void Good_info_con_65()
        {
            List<Candidate_item> Candidates = Test_controller.Candidate_list(65);
            Assert.AreNotEqual(Candidates[0].ID, 0);
            Assert.IsTrue(Candidates.Count == 3);

        }
        [TestMethod]
        public void Null_info_con_999()
        {
            List<Candidate_item> Candidates = Test_controller.Candidate_list(999); //Expect null
            Assert.AreEqual(Candidates.Count,0);

        }
        [TestMethod]
        public void Special_info_con_0()
        {
            List<Candidate_item> Candidates = Test_controller.Candidate_list(0); //Expect ids 330 and 332, is true regardless of order
            Assert.AreEqual(Candidates.Count, 2);
            try
            {
                Assert.AreEqual(Candidates[0].ID, 330);
            }
            catch { Assert.AreEqual(Candidates[0].ID, 332); }
            try
            {
                Assert.AreEqual(Candidates[1].ID, 332);
            }
            catch { Assert.AreEqual(Candidates[1].ID,330); }

        }
        [TestMethod]
        public void Good_response_no_info_no_con()
        {
            int x = 0;
            List<Candidate_item> Candidates = Test_controller.Candidate_list(x);
        }

        //Tests for cast vote
        [TestMethod]
        public void Default_no_info_vote()
        {
            int Status = Test_controller.Cast_vote(0, "");
            Assert.AreEqual(Status, 0);
        }
        /*[TestMethod]
        public void Bad_conection_vote() //cant be run with run all as it needs the db to be manualy turned off
        {
            int Status = Test_controller.Cast_vote(1, "letmein123");
            Assert.AreEqual(Status, 5);
        }*/
        [TestMethod]
        public void Bad_code_vote()
        {
            int Status = Test_controller.Cast_vote(1, "aaaaaaaaaa");
            Assert.AreEqual(Status, 3);
        }
        [TestMethod]
        public void Bad_candidate_vote()
        {
            int Status = Test_controller.Cast_vote(999, "letmein123");
            Assert.AreEqual(Status, 2);
        }
        [TestMethod]
        public void Good_vote()
        {
            int Status = Test_controller.Cast_vote(1,"letmein123");
            using (MySqlCommand Reactivate = new MySqlCommand("UPDATE voter_codes SET Status = @status WHERE Code = @code",Test_con))
            {
                Reactivate.Parameters.AddWithValue("status","active");
                Reactivate.Parameters.AddWithValue("code","letmein123");
                try { Test_con.Open(); } catch { }                
                Reactivate.ExecuteNonQuery();
                try { Test_con.Close(); } catch { }
            }
            Assert.AreEqual(Status, 1);
        }
    }
}
