﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

using System.Data;
using MySql.Data.MySqlClient;
using System.Text.RegularExpressions;
using Election_Api.Models;
using System.Diagnostics;
using System.IO;
using Newtonsoft.Json;


namespace Election_Api.Controllers
{    
    public class Election_controler : Controller
    {
        //TODO: make this connection private when not testing
        public MySqlConnection EApiCon = new MySqlConnection("datasource = 192.168.0.15; port=3306; database=election_db; username=election_user; password=; allow user variables =True");


       public IActionResult Index()
        {
            return View();
        }

        public Election_controler() //Constructor
        {
        }

        [HttpGet("Sanity")]
        public string Sanity_check()
        {
            string Response = "Sanity check complete, you got a response";
            return Response;
        }       

        [HttpGet("Code")]
        public Code_item Verify_code(string Code)
        {
            Code_item Response = new Code_item();
            Response.Valid = false;
            Response.Constituency = 0;

            //screen code, a proper input from the app/service will be clear already but better safe than sorry            
            string Input = Regex.Unescape(Code);
            Input = Input.Trim(' ');
            var regexItem = new Regex("^[a-zA-Z0-9-_*$?,@_%$£]");
            if (!regexItem.IsMatch(Input) || Input.Length != 10)
            {
                return (Response);
            }            

            //Find if code exists and get its con num, if a value is returned check the code is valid, done this way for efficiency
            try
            {
                try { EApiCon.Open(); } catch { }
                using (MySqlCommand Find_code = new MySqlCommand("SELECT Con_num FROM voter_codes WHERE Code = @Input", EApiCon))
                {
                    Find_code.Parameters.AddWithValue("Input", Input);
                    using (MySqlDataReader Reader = Find_code.ExecuteReader())
                    {
                        while (Reader.Read())
                        {
                            Response.Constituency = Reader.GetInt32(0);
                        }
                    }
                }
                string Status_response = "INVALID";
                if (Response.Constituency != 0)
                {
                    using (MySqlCommand Get_status = new MySqlCommand("SELECT Status FROM voter_codes WHERE Code = @Input", EApiCon))
                    {
                        Get_status.Parameters.AddWithValue("Input", Input);
                        using (MySqlDataReader Reader = Get_status.ExecuteReader())
                        {
                            while (Reader.Read())
                            {
                                Status_response = Reader.GetString(0);
                            }
                        }
                    }
                    if (Status_response == "active")
                    {
                        Response.Valid = true;
                    }
                    else
                    {
                        Response.Valid = false;
                    }                    
                }
            }
            catch
            {
                Response.Constituency = 999;
                Response.Valid = false;
            }
            try { EApiCon.Close(); } catch { }
            return (Response);
        }
        
        [HttpGet("Candidate_list")]
        public List<Candidate_item>Candidate_list (int Con_ID)
        {
            List<Candidate_item> Candidates = new List<Candidate_item>();
            DataTable DT = new DataTable();

            try { EApiCon.Open(); } catch { }
            try
            {
                using (MySqlCommand Cmd = new MySqlCommand("", EApiCon))
                {
                    Cmd.CommandText =
                        "SELECT C.ID, C.Candidate_name, C.Party_ID, P.Party_name, P.Party_colour " +
                        "FROM candidates AS C INNER JOIN parties AS P ON C.Party_ID = P.Party_ID " +
                        "WHERE C.Standing_in = @Con_num ORDER BY C.candidate_name LIMIT 10";
                    Cmd.Parameters.AddWithValue("Con_num", Con_ID);
                    using (MySqlDataAdapter SDA = new MySqlDataAdapter(Cmd))
                    {
                        SDA.Fill(DT);
                    }
                }
            }
            catch
            {
                Candidate_item Error_note = new Candidate_item();
                Error_note.ID = 0;
                Error_note.Name = "Error collecting information from the database";
                Candidates.Add(Error_note);
            }
            try
            {
                int Row_count = DT.Rows.Count;
                for (int i = 0; i < Row_count; i++)
                {
                    Candidate_item item = new Candidate_item();
                    item.ID = Convert.ToInt32(DT.Rows[i]["ID"]);
                    item.Name = DT.Rows[i]["Candidate_Name"].ToString();
                    item.Party_id = DT.Rows[i]["Party_ID"].ToString();
                    item.Party_name = DT.Rows[i]["Party_name"].ToString();
                    item.Colour = DT.Rows[i]["Party_colour"].ToString();
                    Candidates.Add(item);
                }
            }
            catch 
            {               
                Candidate_item Error_note = new Candidate_item();
                Error_note.ID = Candidates.Count()+1;
                Error_note.Name = "Error deserialising information from the database";
                Error_note.Party_name = "id number shows index at time of failure";
                Candidates.Add(Error_note);
            }    
            try { EApiCon.Close(); } catch { }
            return (Candidates);
        }       

        [HttpPut("Cast")]
        public int Cast_vote(int Choice, string Code)
        {
            //Status = 0:Default, 1:Success, 2:failure-bad-choice, 3:failure-bad-code, 4:failure-unable-to-change-status, 5:failure-connection-issue, 6:failure-failed-commit
            int Status = 0;
            //Ensure that the code  and choice exist and are good
            if (Choice == 0 || Code =="")
            {
                return (0);
            }
            try { EApiCon.Close(); } catch { }//ensuring that the connection is closed incase it was left open, since the following open returns and error if it fails
            try { EApiCon.Open(); } catch { return (5); }
            Code_item code_Item = Verify_code(Code);
            if (code_Item.Valid != true || code_Item.Constituency == 0 || code_Item.Constituency == 999)
            {
                return (3);
            }
            bool real_candidate = Verify_candidate(Choice);
            if (real_candidate == false)
            {
                return (2);
            }

            //Transaction: add +1 vote to candidate id and invalidate code
            try { EApiCon.Close(); } catch { }//ensuring that the connection is closed incase it was left open, since the following open returns and error if it fails
            try { EApiCon.Open(); } catch { return (5); }
            MySqlTransaction Vote_tr = EApiCon.BeginTransaction();
            try
            {
                MySqlCommand Submit_vote = new MySqlCommand("UPDATE candidates SET Votes = Votes + 1 WHERE ID = @choice",EApiCon,Vote_tr);
                Submit_vote.Parameters.AddWithValue("choice",Choice);
                Submit_vote.ExecuteNonQuery();
            }
            catch 
            {
                Vote_tr.Rollback();
                Vote_tr.Dispose();
                return (2);
            }
            try 
            {
                MySqlCommand Use_code = new MySqlCommand("UPDATE voter_codes SET Status = @status WHERE Code = @code ",EApiCon,Vote_tr);
                Use_code.Parameters.AddWithValue("Code", Code);
                Use_code.Parameters.AddWithValue("status","used");
                Use_code.ExecuteNonQuery();
            }
            catch
            {
                Vote_tr.Rollback();
                Vote_tr.Dispose();
                return (4);
            }
            try
            {
                Vote_tr.Commit();
                Vote_tr.Dispose();
                Status = 1;
            }
            catch
            {
                Vote_tr.Rollback();
                Vote_tr.Dispose();
                Status = 6;
            }

            try { EApiCon.Close(); } catch { }
            return (Status);
        }

        private bool Verify_candidate(int ID)
        {
            bool Exists = false;
            int Collected_id = 0;
            try { EApiCon.Close(); } catch { }//ensuring that the connection is closed incase it was left open, since the following open returns and error if it fails
            try { EApiCon.Open(); } catch {}
            using (MySqlCommand Check_candidate = new MySqlCommand("SELECT ID FROM Candidates WHERE ID = @ID",EApiCon))
            {
                Check_candidate.Parameters.AddWithValue("ID",ID);
                using (MySqlDataReader Reader = Check_candidate.ExecuteReader())
                {
                    while (Reader.Read())
                    {
                        Collected_id = Reader.GetInt32(0);
                    }
                }
            }
            try { EApiCon.Close(); } catch { }
            if (Collected_id == ID)
            {
                Exists = true;
            }
            return (Exists);
        }
    }
}
