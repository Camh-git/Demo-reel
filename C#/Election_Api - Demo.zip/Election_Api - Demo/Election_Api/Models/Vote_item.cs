﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Election_Api.Models
{
    public class Vote_item
    {
        [Required]
        public int Candidate_ID { get; set; }
        
        [Required]
        [StringLength(10)]
        public string Voter_code { get; set; }
    }
}
