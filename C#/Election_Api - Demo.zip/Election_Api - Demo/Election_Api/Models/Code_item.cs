﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace Election_Api.Models
{
    public class Code_item
    {
        [Required]
        public bool Valid { get; set; }

        [Required]
        [MaxLength(3)]
        public int Constituency { get; set; }
    }
}
