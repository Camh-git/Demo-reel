﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Election_Api.Models
{
    public class Candidate_item
    {
        [Required]
        public int ID { get; set; }

        [Required]
        public string Name { get; set; }

        [Required]
        public String Party_id { get; set; }

        [Required]
        public string Party_name { get; set; }

        public string Colour { get; set; }
    }
    public class Candidate_collection
    {
        public Candidate_item[] candidates;
    }

  /*public class DB_return_collection
    {
        public List<DB_return_item> DB_returns;

        public int Count { get { Count = DB_returns.Count; return (Count); } set { Count = DB_returns.Count;} }
           // () =>
          //  DB_returns.Count();
    }*/
}
