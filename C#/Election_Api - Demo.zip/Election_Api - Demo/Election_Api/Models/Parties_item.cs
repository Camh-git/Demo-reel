﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Election_Api.Models
{
    public class Party_item
    {
        [Required]
        public int ID { get; set; }

        [Required]
        [StringLength(4)]
        public string Party_ID { get; set; }

        public string colour { get; set; }

        [Required]
        public string name { get; set; }
    }
    public class Party_collection
    {
        [Required]
        public Party_item[] parties;

       // public DateTime Valid_from { get; set; }
       // public DateTime Valid_until { get; set; }
    }
}
