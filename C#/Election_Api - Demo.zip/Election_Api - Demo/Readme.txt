This folder contains the api solution, it's files and a sql file for a version of the database it uses.

To make this work you will need a sql server running with the database on it.
You may also need to change the connection datasource depending on your configuration.

The connection can be found in the Election_controler class as public MySqlConnection EAPICon, 
you may need to change the datasource and possibly the port to match your server config.

The database file is "election_db.sql".